﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class TinggiTabung : MonoBehaviour {
	[SerializeField] Transform slots;
	[SerializeField] Text tinggiText;
	public static int tinggi;
	int level = new Tabung().getLevel();

	void setVolume(int level){

	}

	//public static int volume = 200;

	// Use this for initialization
	void Start () {
		tinggi = getTinggi(level);
		tinggiText.text = tinggi.ToString() + " cm";
	}

	public int getTinggi(int l){
		if (l == 1)
			tinggi = 100;
		else if (l == 2)
			tinggi = 90;
		else if (l == 3) 
			tinggi = 80;
		return tinggi;
	}
}