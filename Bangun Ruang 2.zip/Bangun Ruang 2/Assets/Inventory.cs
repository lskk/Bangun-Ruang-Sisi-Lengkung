﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Inventory : MonoBehaviour, IHasChanged {
	[SerializeField] Transform slots;
	[SerializeField] Text inventoryText;
	double volume, terisi;
	string done = "";
	// Use this for initialization
	void Start () {
		HasChanged ();
	}

	#region IHasChanged implementation
	public void HasChanged ()
	{
		System.Text.StringBuilder builder = new System.Text.StringBuilder();
		foreach (Transform slotTransform in slots) {
			GameObject item = slotTransform.GetComponent<Slot>().item;
			if (item) {
				terisi = new Tabung().getTerisi();
				volume = new VolumeTabung().getVolume();
				if (terisi < volume) {
					builder.Append ("+ " + item.name + " cc ");
				}
			}
		}
		done = done + builder.ToString ();
		inventoryText.text = "Riwayat:\n" + done;
	}
	#endregion
}

namespace UnityEngine.EventSystems{
	public interface IHasChanged : IEventSystemHandler{
		void HasChanged();
	}
}