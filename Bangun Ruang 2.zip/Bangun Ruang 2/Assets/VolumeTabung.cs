﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class VolumeTabung : MonoBehaviour {
	[SerializeField] Transform slots;
	[SerializeField] Text volumeText;
	public static int diameter, jari, tinggi;
	public static double volume, volumeLiter;
	int level = new Tabung().getLevel();

	void setVolume(int level){
		
	}

	//public static int volume = 200;

	// Use this for initialization
	void Start () {
		getVolume ();
		volumeText.text = "Volume Tabung = ?????";
	}

	public double getVolume(){
		diameter = new DiameterTabung().getDiameter(level);
		tinggi = new TinggiTabung().getTinggi(level);
		
		jari = diameter/2;
		volume = 3.14*jari*jari*tinggi;
		//volumeLiter = volume/1000;
		return volume ;
	}
}