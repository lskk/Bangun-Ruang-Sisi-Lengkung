﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class VolumePenambah : MonoBehaviour, IHasChanged {
	[SerializeField] Transform slots;
	[SerializeField] Text penambahText;
	double volume, terisi;
	// Use this for initialization
	void Start () {
		HasChanged ();
	}

	#region IHasChanged implementation
	public void HasChanged ()
	{
		System.Text.StringBuilder builder = new System.Text.StringBuilder();
		penambahText.text = "";
		foreach (Transform slotTransform in slots) {
			GameObject item = slotTransform.GetComponent<Slot>().item;
			if (item) {
				if (item) {
					terisi = new Tabung().getTerisi();
					volume = new VolumeTabung().getVolume();
					if (terisi < volume) {
						builder.Append ("+" + item.name + " cc");
					}
				}
			}
		}
		penambahText.text = builder.ToString ();
	}
	#endregion
}