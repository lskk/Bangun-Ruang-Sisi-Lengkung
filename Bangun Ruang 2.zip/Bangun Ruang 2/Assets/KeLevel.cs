﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class KeLevel : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void LoadLevel1(){
		SceneManager.LoadScene("Level1");
		new Tabung().setLevel(1);
		new Tabung().setI(0);
	}
	public void LoadLevel2(){
		SceneManager.LoadScene("Level2");
		new Tabung().setLevel(2);
		new Tabung().setI(0);
	}
	public void LoadLevel3(){
		SceneManager.LoadScene("Level3");
		new Tabung().setLevel(3);
		new Tabung().setI(0);
	}
}
