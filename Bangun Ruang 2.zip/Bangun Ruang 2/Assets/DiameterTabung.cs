﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class DiameterTabung : MonoBehaviour {
	[SerializeField] Transform slots;
	[SerializeField] Text diameterText;
	public static int diameter;
	int level = new Tabung().getLevel();

	void setVolume(int level){

	}

	//public static int volume = 200;

	// Use this for initialization
	void Start () {
		diameter = getDiameter(level);
		diameterText.text = diameter.ToString() + " cm";
	}

	public int getDiameter(int l){
		if (l == 1)
			diameter = 14;
		else if (l == 2)
			diameter = 28;
		else if (l == 3)
			diameter = 42;
		return diameter;
	}
}