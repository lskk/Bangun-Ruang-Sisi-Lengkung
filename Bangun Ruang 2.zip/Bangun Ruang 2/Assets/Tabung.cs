﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Tabung : MonoBehaviour, IHasChanged {
	[SerializeField] Transform slots;
	[SerializeField] Text tabungText;
	public GameObject btnNaikLevel;
	public static double volume = new VolumeTabung().getVolume();
	public double tumpah;
	public static int terisi;
	public static int i = 0;
	public static int level = 1;
	// Use this for initialization
	void Start () {
		terisi = 0;
		getLevel();
		HasChanged ();
		volume = new VolumeTabung().getVolume();
		tabungText.text = terisi.ToString() + " cc";
	}

	void activateNextButton(){
		//yield return new WaitForSeconds (10f);
		btnNaikLevel = GameObject.FindGameObjectWithTag ("nextButton");
		btnNaikLevel.GetComponent<Button> ().interactable = true;
		btnNaikLevel.gameObject.tag = "Untagged";
	}

	public void setI(int index){
		i = index;
	}

	public int getLevel(){
		return level;
	}
	public void setLevel(int l){
		level = l;
	}

	#region IHasChanged implementation
	public void HasChanged ()
	{
		System.Text.StringBuilder builder = new System.Text.StringBuilder();
		builder.Append (terisi.ToString());
		foreach (Transform slotTransform in slots) {
			GameObject item = slotTransform.GetComponent<Slot>().item;
			if (item) {
				terisi += int.Parse(item.name);
				setTerisi(terisi);
				volume = new VolumeTabung().getVolume();
				if (terisi >= volume) {
					if (i == 0) {
						tumpah = getTumpah ();
						tabungText.text = "Air pengisi = " + terisi.ToString () + " cc\nAir tumpah = " + tumpah.ToString () + " cc";
						i++;
						activateNextButton ();
					}
				} else {
					tabungText.text = "Air pengisi = " + terisi.ToString () + " cc";
				}
			}
		}
		//tabungText.text = builder.ToString ();
	}
	#endregion

	public void setToZero(){
		terisi = 0;
		//SceneManager.LoadScene("Level2");
	}
	public int getTerisi(){
		return terisi;
	}
	public void setTerisi(int t){
		terisi = t;
	}
	public double getTumpah(){
		return terisi - volume;
	}
}